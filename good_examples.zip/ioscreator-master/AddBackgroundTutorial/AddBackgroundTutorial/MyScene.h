//
//  MyScene.h
//  AddBackgroundTutorial
//

//  Copyright (c) 2013 Arthur Knopper. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface MyScene : SKScene

@end
