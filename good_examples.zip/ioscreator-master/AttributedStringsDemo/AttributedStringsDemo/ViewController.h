//
//  ViewController.h
//  AttributedStringsDemo
//
//  Created by Arthur Knopper on 16/10/12.
//  Copyright (c) 2012 iOSCreator. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
