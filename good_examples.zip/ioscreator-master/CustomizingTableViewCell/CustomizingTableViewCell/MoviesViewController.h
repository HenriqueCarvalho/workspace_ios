//
//  MoviesViewController.h
//  CustomizingTableViewCell
//
//  Created by Arthur Knopper on 1/2/13.
//  Copyright (c) 2013 Arthur Knopper. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoviesViewController : UITableViewController

@property (nonatomic,strong) NSMutableArray *movies;

@end
