//
//  DragView2.h
//  DragViewDemo
//
//  Created by Arthur Knopper on 1/13/13.
//  Copyright (c) 2013 Arthur Knopper. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DragView2 : UIView
{
    CGPoint lastLocation;
}

@end
