//
//  customCell.swift
//  IOS8SwiftCustomCollectionViewCellsTutorial
//
//  Created by Arthur Knopper on 24/12/14.
//  Copyright (c) 2014 Arthur Knopper. All rights reserved.
//

import UIKit

class customCell: UICollectionViewCell {
    
}
